package juego;

public abstract class Personaje {
    protected String nombre;
    protected int vida;
    protected int nivel;

    public Personaje(String nombre, int vida, int nivel) {
        this.nombre = nombre;
        this.vida = vida;
        this.nivel = nivel;
    }

    public abstract void atacar(Personaje enemigo);

    public void defender(int daño) {
        vida -= daño;
        if (vida < 0) vida = 0;
    }

    public void subirNivel() {
        nivel++;
        vida += 20;
        System.out.println(nombre + " sube a nivel " + nivel + " con " + vida + " puntos de vida.");
    }

    public boolean estaVivo() {
        return vida > 0;
    }

    public String getNombre() {
        return nombre;
    }

    public int getVida() {
        return vida;
    }

    public int getNivel() {
        return nivel;
    }
}