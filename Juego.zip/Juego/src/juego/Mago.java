package juego;

public class Mago extends Personaje {

    public Mago(String nombre) {
        super(nombre, 80, 1);
    }

    public void atacar(Personaje enemigo) {
        int daño = 25 + (nivel * 3);
        System.out.println(nombre + " lanza hechizo a " + enemigo.getNombre() + " causando " + daño + " de daño.");
        enemigo.defender(daño);
    }
}
