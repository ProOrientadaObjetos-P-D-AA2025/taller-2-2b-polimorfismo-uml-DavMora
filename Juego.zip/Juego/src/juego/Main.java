package juego;

public class Main {
    public static void main(String[] args) {
        
        Personaje personaje1 = new Guerrero("Kratos");
        Personaje personaje2 = new Mago("Harry");

       
        System.out.println(" Bienvenido al RPG - Combate automático ");
        System.out.println("Jugador 1: " + personaje1.getNombre() + " (Nivel " + personaje1.getNivel() + ")");
        System.out.println("Jugador 2: " + personaje2.getNombre() + " (Nivel " + personaje2.getNivel() + ")");

        
        ControladorCombate combate = new ControladorCombate();
        combate.combatir(personaje1, personaje2);
    }
}
 
