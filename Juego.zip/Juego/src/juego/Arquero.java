package juego;

public class Arquero extends Personaje {

    public Arquero(String nombre) {
        super(nombre, 100, 1);
    }

    public void atacar(Personaje enemigo) {
        int daño = 18 + (nivel * 2);
        System.out.println(nombre + " dispara flecha a " + enemigo.getNombre() + " causando " + daño + " de daño.");
        enemigo.defender(daño);
    }
}
