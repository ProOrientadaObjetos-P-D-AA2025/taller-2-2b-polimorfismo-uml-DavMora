/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package juegorpg;



public class Ejecutor {
    public static void main(String[] args) {
  
        Guerrero personaje1 = new Guerrero("Kratos");
        Mago personaje2 = new Mago("Harry");

       
        System.out.println(" Bienvenido al RPG");
        System.out.println("Jugador 1: " + personaje1.getNombre() + " (Nivel " + personaje1.getNivel() + ")");
        System.out.println("Jugador 2: " + personaje2.getNombre() + " (Nivel " + personaje2.getNivel() + ")");

        ControladorCombate combate = new ControladorCombate();
        combate.combatir(personaje1, personaje2);
    }
}
