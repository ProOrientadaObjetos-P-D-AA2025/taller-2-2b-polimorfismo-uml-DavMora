package juego;

public class ControladorCombate {

    public void combatir(Personaje p1, Personaje p2) {
        System.out.println("\n Combate entre " + p1.getNombre() + " y " + p2.getNombre());

        while (p1.estaVivo() && p2.estaVivo()) {
            p1.atacar(p2);
            if (p2.estaVivo()) {
                p2.atacar(p1);
            }
        }

        if (p1.estaVivo()) {
            System.out.println(p1.getNombre() + " ha ganado.");
            p1.subirNivel();
        } else {
            System.out.println(p2.getNombre() + " ha ganado.");
            p2.subirNivel();
        }
    }
}
