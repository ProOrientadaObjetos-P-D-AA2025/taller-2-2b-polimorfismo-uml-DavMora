package juego;

public class Guerrero extends Personaje {

    public Guerrero(String nombre) {
        super(nombre, 120, 1);
    }

    public void atacar(Personaje enemigo) {
        int daño = 20 + (nivel * 2);
        System.out.println(nombre + " ataca con espada a " + enemigo.getNombre() + " causando " + daño + " de daño.");
        enemigo.defender(daño);

    }
}
